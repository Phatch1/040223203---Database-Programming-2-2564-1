﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Lab5_5
{
    public partial class formTitles : Form
    {
        CurrencyManager titlesManager;
        SqlConnection booksConnection;
        SqlCommand titlesCommand;
        SqlDataReader titlesAdapter;
        DataTable titlesTable;
        
        public formTitles()
        {
            InitializeComponent();
        }

        private void formTitles_Load(object sender, EventArgs e)
        {
            var booksConnection = new SqlConnection(
                           "Data Source=LEGIONY450;" + "Initial Catalog=DemoBooksDB;" + "User ID=user1;" + "Password=mypass1;");
            // Open the connection   
            booksConnection.Open();
            var command = new SqlCommand("Select * from Titles", booksConnection);
            var titlesAdapter = new SqlDataAdapter();
            titlesAdapter.SelectCommand = command;
            var titlesTable = new DataTable();
            titlesAdapter.Fill(titlesTable);

            textTitle.DataBindings.Add("Text", titlesTable, "Title");
            textYearPublished.DataBindings.Add("Text", titlesTable, "Year_Published");
            textISBN.DataBindings.Add("Text", titlesTable, "ISBN");
            textPubID.DataBindings.Add("Text", titlesTable, "PubID");

            titlesManager = (CurrencyManager)BindingContext[titlesTable];

            booksConnection.Close();
            // Dispose of the connection object   
            booksConnection.Dispose();
            command.Dispose();
            titlesAdapter.Dispose();
            titlesTable.Dispose();

        }

        private void buttonFirst_Click(object sender, EventArgs e)
        {
            titlesManager.Position = 0;
        }

        private void buttonPrevious_Click(object sender, EventArgs e)
        {
            titlesManager.Position --;
        }

        private void buttonNext_Click(object sender, EventArgs e)
        {
            titlesManager.Position ++;
        }

        private void buttonLast_Click(object sender, EventArgs e)
        {
            titlesManager.Position = titlesManager.Count -1;
        }
    }
}
