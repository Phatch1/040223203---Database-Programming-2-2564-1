﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _5_3
{
    public partial class formTitles : Form
    {
        
        public formTitles()
        {
            InitializeComponent();
        }

        private void formTitles_Load(object sender, EventArgs e)
        {
            var booksConnection = new SqlConnection(
                            "Data Source=LEGIONY450;" + "Initial Catalog=DemoBooksDB;" + "User ID=user1;" + "Password=mypass1;");
            booksConnection.Open();
            lblState.Text += booksConnection.State.ToString() + "\n";
            var titlesCommand = new SqlCommand("Select * from Titles", booksConnection);
            var titlesAdapter = new SqlDataAdapter();
            titlesAdapter.SelectCommand = titlesCommand;
            var titlesTable = new DataTable();
            titlesAdapter.Fill(titlesTable);
            booksConnection.Close();
            lblState.Text += booksConnection.State.ToString() + "\n";
            booksConnection.Dispose();
            titlesCommand.Dispose();
            titlesAdapter.Dispose();
            titlesTable.Dispose();
        }
    }
}
