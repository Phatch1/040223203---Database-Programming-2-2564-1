﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Lab3_1
{
    public partial class โปรแกรมเชื : Form
    {
        public โปรแกรมเชื()
        {
            InitializeComponent();
        }

        SqlConnection cnn;
        private void buttonConnect_Click(object sender, EventArgs e)
        {
            try
            {
                string strConnectionString;
                SqlConnection cnn;
                strConnectionString = @"Data Source=LEGIONY450;
                Initial Catalog = DemoTutorialDB;User ID=user1;Password=mypass1";
                cnn = new SqlConnection(strConnectionString);
                cnn.Open();
                MessageBox.Show("การเชอมต่อสําเร็จ", "เชื่อมต่อ",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information,
                MessageBoxDefaultButton.Button1);

                cnn.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("มปีัญหาการเชื่อมต่อ!"+ex.Message, "ข้อผิดพลาด",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error,
                MessageBoxDefaultButton.Button1);
            }
        }

      
        }
    }

