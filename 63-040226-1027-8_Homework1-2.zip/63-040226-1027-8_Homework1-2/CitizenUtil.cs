﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Lab1_2
{
    static class CitizenUtil
    {
        public static string CID { get; set; }
        public static string Prefix { get; set; }
        public static string FirstN { get; set; }
        public static string LastN { get; set; }
        public static string DOB { get; set; }
        public static string HomeN { get; set; }
        public static string Moo { get; set; }
        public static string Soi { get; set; }
        public static string Road { get; set; }
        public static string SubD { get; set; }
        public static string District { get; set; }
        public static string Province { get; set; }
        public static bool ValidateFormat(string input)
        {

            Regex r = new Regex(@"^\d{1}\-{1}\d{4}\-{1}\d{5}\-{1}\d{2}\-{1}\d{1}");
          return r.IsMatch(input);
        }
        public static string GetBasicInfo(string input)
        {
            if (ValidateFormat(input) == false)
            {
                throw new FormatException();
            }
            else
            {
                return "CitizenID :" + CID +
                       "\nPrefix :" + Prefix +
                       "\nFirst Name :" + FirstN +
                       "\nLast Name :" + LastN +
                       "\nDOB :" + DOB +
                       "\nHouse Number :" + HomeN +
                       "\nMoo :" + Moo +
                       "\nSoi :" + Soi +
                       "\nRoad :" + Road +
                       "\nSub District :" + SubD +
                       "\nDistrict :" + District +
                       "\nProvince :" + Province;
            }
        }

    }
}
