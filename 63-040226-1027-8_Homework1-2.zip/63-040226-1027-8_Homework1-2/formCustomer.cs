﻿using System;
using System.Windows.Forms;

namespace Lab1_2
{
    public partial class formCustomer : Form
    {
        string[] province = {"กรุงเทพมหานคร","กระบี่","กาญจนบุรี","กาฬสินธุ์","กำแพงเพชร","ขอนแก่น","จันทบุรี","ฉะเชิงเทรา","ชลบุรี",
                            "ชัยนาท","ชัยภูมิ","ชุมพร","เชียงราย","เชียงใหม่","ตรัง","ตราด","ตาก","นครนายก","นครปฐม","นครพนม","นครราชสีมา",
                            "นครศรีธรรมราช","นครสวรรค์","นนทบุรี","นราธิวาส","น่าน","บึงกาฬ","บุรีรัมย์","ปทุมธานี","ประจวบคีรีขันธ์","ปราจีนบุรี",
                            "ปัตตานี","พระนครศรีอยุธยา","พังงา","พัทลุง","พิจิตร","พิษณุโลก","เพชรบุรี","เพชรบูรณ์","แพร่","พะเยา","ภูเก็ต","มหาสารคาม",
                            "มุกดาหาร","แม่ฮ่องสอน","ยะลา","ยโสธร","ร้อยเอ็ด","ระนอง","ระยอง","ราชบุรี","ลพบุรี","ลำปาง","ลำพูน","เลย",
                            "ศรีสะเกษ","สกลนคร","สงขลา","สตูล","สมุทรปราการ","สมุทรสงคราม","สมุทรสาคร","สระแก้ว","สระบุรี","สิงห์บุรี","สุโขทัย","สุพรรณบุรี","สุราษฎร์ธานี","สุรินทร์","หนองคาย",
                            "หนองบัวลำภู","อ่างทอง","อุดรธานี","อุทัยธานี","อุตรดิตถ์","อุบลราชธานี","อำนาจเจริญ"};
        public formCustomer()
        {
            InitializeComponent();
        }

        private void formCustomer_Load(object sender, EventArgs e)
        {

        }

        private void comboCusGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            textCusCode.Text = comboCusGroup.Text + textCusID.Text;
        }

        private void textCusID_TextChanged(object sender, EventArgs e)
        {
            textCusCode.Text = comboCusGroup.Text + textCusID.Text;
        }

        private void textCusPrefixCOde_TextChanged(object sender, EventArgs e)
        {
            int input;
            if(!int.TryParse(textCusPrefixCode.Text, out input) || (input < 1 || input > 5))
            {
                if (textCusProvinceCode.Text == string.Empty)
                {
                    return;
                }
                MessageBox.Show("กรุณาใส่ข้อมูลเป็นจำนวนเต็ม1-4");
                return;
            }
            switch (input)
            {
                case 1:
                    textCusPrefix.Text = "นาย";
                    textCusPrefix.ReadOnly = true;
                    break;
                case 2:
                    textCusPrefix.Text = "นาง";
                    textCusPrefix.ReadOnly = true;
                    break;
                case 3:
                    textCusPrefix.Text = "นางสาว";
                    textCusPrefix.ReadOnly = true;
                    break;
                case 4:
                    textCusPrefix.ReadOnly = false;
                    break;
            }
        }

        private void textCusProvinceCode_TextChanged(object sender, EventArgs e)
        {
            int input;
            if (!int.TryParse(textCusProvinceCode.Text, out input) || input > 77 || input <= 0)
            {
                if(textCusProvinceCode.Text == string.Empty)
                {
                    return;
                }
                MessageBox.Show("กรุณาใส่ข้อมูลเป็นจำนวนเต็ม1-77");
                return;
            }
            textCusProvince.Text = province[input-1];
        }

        private void buttonInfoFromCitizenID_Click(object sender, EventArgs e)
        {
            
            CitizenUtil.CID = textCusCitizenID.Text;
            CitizenUtil.Prefix = textCusPrefix.Text;
            CitizenUtil.FirstN = textCusName.Text;
            CitizenUtil.LastN = textCusLAstName.Text;
            CitizenUtil.DOB = dtCusDOB.Text;
            CitizenUtil.HomeN = textCusHouseNumber.Text;
            CitizenUtil.Moo = textCusMoo.Text;
            CitizenUtil.Soi = textCusSio.Text;
            CitizenUtil.Road = textCusRoad.Text;
            CitizenUtil.SubD = textCusSubDistrict.Text;
            CitizenUtil.District = textCusDistrict.Text;
            CitizenUtil.Province = textCusProvince.Text;

            try

            {
                MessageBox.Show(CitizenUtil.GetBasicInfo(textCusCitizenID.Text));
            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
    }

