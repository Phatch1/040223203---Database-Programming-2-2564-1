﻿namespace Lab1_2
{
    partial class formCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.toolStripSaveCus = new System.Windows.Forms.ToolStripButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioCusBranch = new System.Windows.Forms.RadioButton();
            this.radioCusHostOffice = new System.Windows.Forms.RadioButton();
            this.textCusBranchCode = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textCusBranchName = new System.Windows.Forms.TextBox();
            this.checkCusSMS = new System.Windows.Forms.CheckBox();
            this.textCusDistric = new System.Windows.Forms.TextBox();
            this.textCusDistrict = new System.Windows.Forms.TextBox();
            this.textCusProvince = new System.Windows.Forms.TextBox();
            this.textCusProvinceCode = new System.Windows.Forms.TextBox();
            this.toolStripCustomer = new System.Windows.Forms.ToolStrip();
            this.toolStripAddCus = new System.Windows.Forms.ToolStripButton();
            this.toolStripEditCus = new System.Windows.Forms.ToolStripButton();
            this.toolStripCancelCus = new System.Windows.Forms.ToolStripButton();
            this.dtCusDOB = new System.Windows.Forms.DateTimePicker();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.textCusSio = new System.Windows.Forms.TextBox();
            this.textCusPostalCode = new System.Windows.Forms.TextBox();
            this.textCusSubDistrict = new System.Windows.Forms.TextBox();
            this.textCusNationallity = new System.Windows.Forms.TextBox();
            this.textCusHouseNumber = new System.Windows.Forms.TextBox();
            this.textCusEmail = new System.Windows.Forms.TextBox();
            this.textCusMobile = new System.Windows.Forms.TextBox();
            this.textCusTel = new System.Windows.Forms.TextBox();
            this.textCusCitizenID = new System.Windows.Forms.TextBox();
            this.textCusRoad = new System.Windows.Forms.TextBox();
            this.radioCusFemale = new System.Windows.Forms.RadioButton();
            this.radioCusOrg = new System.Windows.Forms.RadioButton();
            this.radioCusMale = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.radioCusPersonal = new System.Windows.Forms.RadioButton();
            this.textCusMoo = new System.Windows.Forms.TextBox();
            this.textCusLAstName = new System.Windows.Forms.TextBox();
            this.textCusName = new System.Windows.Forms.TextBox();
            this.textCusPrefix = new System.Windows.Forms.TextBox();
            this.textCusCode = new System.Windows.Forms.TextBox();
            this.textCusPrefixCode = new System.Windows.Forms.TextBox();
            this.textCusID = new System.Windows.Forms.TextBox();
            this.comboCusGroup = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonInfoFromCitizenID = new System.Windows.Forms.Button();
            this.groupBox3.SuspendLayout();
            this.toolStripCustomer.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripSaveCus
            // 
            this.toolStripSaveCus.Image = global::Lab1_2.Properties.Resources.Save;
            this.toolStripSaveCus.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSaveCus.Name = "toolStripSaveCus";
            this.toolStripSaveCus.Size = new System.Drawing.Size(69, 24);
            this.toolStripSaveCus.Text = "บันทึก";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioCusBranch);
            this.groupBox3.Controls.Add(this.radioCusHostOffice);
            this.groupBox3.Controls.Add(this.textCusBranchCode);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.textCusBranchName);
            this.groupBox3.Location = new System.Drawing.Point(34, 606);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(633, 94);
            this.groupBox3.TabIndex = 65;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "ติดต่อที่";
            // 
            // radioCusBranch
            // 
            this.radioCusBranch.AutoSize = true;
            this.radioCusBranch.Location = new System.Drawing.Point(201, 42);
            this.radioCusBranch.Name = "radioCusBranch";
            this.radioCusBranch.Size = new System.Drawing.Size(94, 33);
            this.radioCusBranch.TabIndex = 0;
            this.radioCusBranch.TabStop = true;
            this.radioCusBranch.Text = "สาขาที่";
            this.radioCusBranch.UseVisualStyleBackColor = true;
            // 
            // radioCusHostOffice
            // 
            this.radioCusHostOffice.AutoSize = true;
            this.radioCusHostOffice.Location = new System.Drawing.Point(20, 42);
            this.radioCusHostOffice.Name = "radioCusHostOffice";
            this.radioCusHostOffice.Size = new System.Drawing.Size(164, 33);
            this.radioCusHostOffice.TabIndex = 0;
            this.radioCusHostOffice.TabStop = true;
            this.radioCusHostOffice.Text = "สำนักงานใหญ่";
            this.radioCusHostOffice.UseVisualStyleBackColor = true;
            // 
            // textCusBranchCode
            // 
            this.textCusBranchCode.Location = new System.Drawing.Point(298, 41);
            this.textCusBranchCode.Name = "textCusBranchCode";
            this.textCusBranchCode.Size = new System.Drawing.Size(65, 34);
            this.textCusBranchCode.TabIndex = 11;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(369, 46);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(85, 29);
            this.label20.TabIndex = 13;
            this.label20.Text = "ชื่อสาขา";
            // 
            // textCusBranchName
            // 
            this.textCusBranchName.Location = new System.Drawing.Point(460, 43);
            this.textCusBranchName.Name = "textCusBranchName";
            this.textCusBranchName.Size = new System.Drawing.Size(153, 34);
            this.textCusBranchName.TabIndex = 11;
            // 
            // checkCusSMS
            // 
            this.checkCusSMS.AutoSize = true;
            this.checkCusSMS.Location = new System.Drawing.Point(371, 492);
            this.checkCusSMS.Name = "checkCusSMS";
            this.checkCusSMS.Size = new System.Drawing.Size(87, 33);
            this.checkCusSMS.TabIndex = 64;
            this.checkCusSMS.Text = "SMS";
            this.checkCusSMS.UseVisualStyleBackColor = true;
            // 
            // textCusDistric
            // 
            this.textCusDistric.Location = new System.Drawing.Point(196, 453);
            this.textCusDistric.Name = "textCusDistric";
            this.textCusDistric.ReadOnly = true;
            this.textCusDistric.Size = new System.Drawing.Size(147, 34);
            this.textCusDistric.TabIndex = 61;
            // 
            // textCusDistrict
            // 
            this.textCusDistrict.Location = new System.Drawing.Point(113, 453);
            this.textCusDistrict.Name = "textCusDistrict";
            this.textCusDistrict.Size = new System.Drawing.Size(77, 34);
            this.textCusDistrict.TabIndex = 63;
            // 
            // textCusProvince
            // 
            this.textCusProvince.Location = new System.Drawing.Point(196, 419);
            this.textCusProvince.Name = "textCusProvince";
            this.textCusProvince.ReadOnly = true;
            this.textCusProvince.Size = new System.Drawing.Size(147, 34);
            this.textCusProvince.TabIndex = 60;
            // 
            // textCusProvinceCode
            // 
            this.textCusProvinceCode.Location = new System.Drawing.Point(113, 419);
            this.textCusProvinceCode.Name = "textCusProvinceCode";
            this.textCusProvinceCode.Size = new System.Drawing.Size(77, 34);
            this.textCusProvinceCode.TabIndex = 62;
            this.textCusProvinceCode.TextChanged += new System.EventHandler(this.textCusProvinceCode_TextChanged);
            // 
            // toolStripCustomer
            // 
            this.toolStripCustomer.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStripCustomer.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStripCustomer.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripAddCus,
            this.toolStripEditCus,
            this.toolStripSaveCus,
            this.toolStripCancelCus});
            this.toolStripCustomer.Location = new System.Drawing.Point(0, 789);
            this.toolStripCustomer.Name = "toolStripCustomer";
            this.toolStripCustomer.Size = new System.Drawing.Size(679, 27);
            this.toolStripCustomer.TabIndex = 67;
            this.toolStripCustomer.Text = "toolStrip1";
            // 
            // toolStripAddCus
            // 
            this.toolStripAddCus.Image = global::Lab1_2.Properties.Resources.Add;
            this.toolStripAddCus.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAddCus.Name = "toolStripAddCus";
            this.toolStripAddCus.Size = new System.Drawing.Size(55, 24);
            this.toolStripAddCus.Text = "เพิ่ม";
            this.toolStripAddCus.ToolTipText = "เพิ่ม";
            // 
            // toolStripEditCus
            // 
            this.toolStripEditCus.Image = global::Lab1_2.Properties.Resources.Edit;
            this.toolStripEditCus.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripEditCus.Name = "toolStripEditCus";
            this.toolStripEditCus.Size = new System.Drawing.Size(64, 24);
            this.toolStripEditCus.Text = "แก้ไข";
            // 
            // toolStripCancelCus
            // 
            this.toolStripCancelCus.Image = global::Lab1_2.Properties.Resources.Cancel;
            this.toolStripCancelCus.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripCancelCus.Name = "toolStripCancelCus";
            this.toolStripCancelCus.Size = new System.Drawing.Size(71, 24);
            this.toolStripCancelCus.Text = "ยกเลิก";
            // 
            // dtCusDOB
            // 
            this.dtCusDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtCusDOB.Location = new System.Drawing.Point(113, 312);
            this.dtCusDOB.MaxDate = new System.DateTime(2057, 12, 31, 0, 0, 0, 0);
            this.dtCusDOB.MinDate = new System.DateTime(1907, 1, 1, 0, 0, 0, 0);
            this.dtCusDOB.Name = "dtCusDOB";
            this.dtCusDOB.Size = new System.Drawing.Size(198, 34);
            this.dtCusDOB.TabIndex = 66;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(32, 574);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(82, 29);
            this.label18.TabIndex = 58;
            this.label18.Text = "E-mail";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(13, 533);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(115, 29);
            this.label17.TabIndex = 57;
            this.label17.Text = "เบอร์มือถือ";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(369, 456);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(140, 29);
            this.label19.TabIndex = 54;
            this.label19.Text = "รหัสไปรษณีย์";
            // 
            // textCusSio
            // 
            this.textCusSio.Location = new System.Drawing.Point(444, 350);
            this.textCusSio.Name = "textCusSio";
            this.textCusSio.Size = new System.Drawing.Size(65, 34);
            this.textCusSio.TabIndex = 44;
            // 
            // textCusPostalCode
            // 
            this.textCusPostalCode.Location = new System.Drawing.Point(515, 453);
            this.textCusPostalCode.Name = "textCusPostalCode";
            this.textCusPostalCode.Size = new System.Drawing.Size(122, 34);
            this.textCusPostalCode.TabIndex = 43;
            // 
            // textCusSubDistrict
            // 
            this.textCusSubDistrict.Location = new System.Drawing.Point(494, 388);
            this.textCusSubDistrict.Name = "textCusSubDistrict";
            this.textCusSubDistrict.Size = new System.Drawing.Size(122, 34);
            this.textCusSubDistrict.TabIndex = 42;
            // 
            // textCusNationallity
            // 
            this.textCusNationallity.Location = new System.Drawing.Point(387, 308);
            this.textCusNationallity.Name = "textCusNationallity";
            this.textCusNationallity.Size = new System.Drawing.Size(122, 34);
            this.textCusNationallity.TabIndex = 41;
            // 
            // textCusHouseNumber
            // 
            this.textCusHouseNumber.Location = new System.Drawing.Point(113, 348);
            this.textCusHouseNumber.Name = "textCusHouseNumber";
            this.textCusHouseNumber.Size = new System.Drawing.Size(122, 34);
            this.textCusHouseNumber.TabIndex = 40;
            // 
            // textCusEmail
            // 
            this.textCusEmail.Location = new System.Drawing.Point(136, 574);
            this.textCusEmail.Name = "textCusEmail";
            this.textCusEmail.Size = new System.Drawing.Size(230, 34);
            this.textCusEmail.TabIndex = 38;
            // 
            // textCusMobile
            // 
            this.textCusMobile.Location = new System.Drawing.Point(134, 530);
            this.textCusMobile.Name = "textCusMobile";
            this.textCusMobile.Size = new System.Drawing.Size(230, 34);
            this.textCusMobile.TabIndex = 46;
            // 
            // textCusTel
            // 
            this.textCusTel.Location = new System.Drawing.Point(113, 490);
            this.textCusTel.Name = "textCusTel";
            this.textCusTel.Size = new System.Drawing.Size(230, 34);
            this.textCusTel.TabIndex = 37;
            // 
            // textCusCitizenID
            // 
            this.textCusCitizenID.Location = new System.Drawing.Point(385, 268);
            this.textCusCitizenID.Name = "textCusCitizenID";
            this.textCusCitizenID.Size = new System.Drawing.Size(230, 34);
            this.textCusCitizenID.TabIndex = 32;
            // 
            // textCusRoad
            // 
            this.textCusRoad.Location = new System.Drawing.Point(113, 385);
            this.textCusRoad.Name = "textCusRoad";
            this.textCusRoad.Size = new System.Drawing.Size(230, 34);
            this.textCusRoad.TabIndex = 35;
            // 
            // radioCusFemale
            // 
            this.radioCusFemale.AutoSize = true;
            this.radioCusFemale.Location = new System.Drawing.Point(69, 24);
            this.radioCusFemale.Name = "radioCusFemale";
            this.radioCusFemale.Size = new System.Drawing.Size(76, 33);
            this.radioCusFemale.TabIndex = 0;
            this.radioCusFemale.TabStop = true;
            this.radioCusFemale.Text = "หญิง";
            this.radioCusFemale.UseVisualStyleBackColor = true;
            // 
            // radioCusOrg
            // 
            this.radioCusOrg.AutoSize = true;
            this.radioCusOrg.Location = new System.Drawing.Point(206, 25);
            this.radioCusOrg.Name = "radioCusOrg";
            this.radioCusOrg.Size = new System.Drawing.Size(115, 33);
            this.radioCusOrg.TabIndex = 0;
            this.radioCusOrg.TabStop = true;
            this.radioCusOrg.Text = "นิติบุคคล";
            this.radioCusOrg.UseVisualStyleBackColor = true;
            // 
            // radioCusMale
            // 
            this.radioCusMale.AutoSize = true;
            this.radioCusMale.Location = new System.Drawing.Point(6, 24);
            this.radioCusMale.Name = "radioCusMale";
            this.radioCusMale.Size = new System.Drawing.Size(69, 33);
            this.radioCusMale.TabIndex = 0;
            this.radioCusMale.TabStop = true;
            this.radioCusMale.Text = "ชาย";
            this.radioCusMale.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(12, 492);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(95, 29);
            this.label16.TabIndex = 56;
            this.label16.Text = "โทรศัพท์";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(59, 456);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 29);
            this.label15.TabIndex = 59;
            this.label15.Text = "เขต";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(38, 422);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(74, 29);
            this.label14.TabIndex = 55;
            this.label14.Text = "จังหวัด";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(369, 388);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(119, 29);
            this.label13.TabIndex = 49;
            this.label13.Text = "ตำบล/แขวง";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(49, 388);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 29);
            this.label12.TabIndex = 50;
            this.label12.Text = "ถนน";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(380, 355);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 29);
            this.label11.TabIndex = 51;
            this.label11.Text = "ซอย";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(237, 353);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 29);
            this.label10.TabIndex = 52;
            this.label10.Text = "หมู่ที่";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(30, 353);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 29);
            this.label9.TabIndex = 53;
            this.label9.Text = "เลขที่อยู่";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(302, 315);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 29);
            this.label8.TabIndex = 48;
            this.label8.Text = "สัญชาติ";
            // 
            // radioCusPersonal
            // 
            this.radioCusPersonal.AutoSize = true;
            this.radioCusPersonal.Location = new System.Drawing.Point(6, 28);
            this.radioCusPersonal.Name = "radioCusPersonal";
            this.radioCusPersonal.Size = new System.Drawing.Size(161, 33);
            this.radioCusPersonal.TabIndex = 0;
            this.radioCusPersonal.TabStop = true;
            this.radioCusPersonal.Text = "บุคคลธรรมดา";
            this.radioCusPersonal.UseVisualStyleBackColor = true;
            // 
            // textCusMoo
            // 
            this.textCusMoo.Location = new System.Drawing.Point(299, 350);
            this.textCusMoo.Name = "textCusMoo";
            this.textCusMoo.Size = new System.Drawing.Size(65, 34);
            this.textCusMoo.TabIndex = 31;
            // 
            // textCusLAstName
            // 
            this.textCusLAstName.Location = new System.Drawing.Point(136, 153);
            this.textCusLAstName.Name = "textCusLAstName";
            this.textCusLAstName.Size = new System.Drawing.Size(230, 34);
            this.textCusLAstName.TabIndex = 36;
            // 
            // textCusName
            // 
            this.textCusName.Location = new System.Drawing.Point(136, 113);
            this.textCusName.Name = "textCusName";
            this.textCusName.Size = new System.Drawing.Size(230, 34);
            this.textCusName.TabIndex = 39;
            // 
            // textCusPrefix
            // 
            this.textCusPrefix.Location = new System.Drawing.Point(219, 73);
            this.textCusPrefix.Name = "textCusPrefix";
            this.textCusPrefix.ReadOnly = true;
            this.textCusPrefix.Size = new System.Drawing.Size(147, 34);
            this.textCusPrefix.TabIndex = 47;
            // 
            // textCusCode
            // 
            this.textCusCode.Location = new System.Drawing.Point(136, 43);
            this.textCusCode.Name = "textCusCode";
            this.textCusCode.ReadOnly = true;
            this.textCusCode.Size = new System.Drawing.Size(230, 34);
            this.textCusCode.TabIndex = 33;
            // 
            // textCusPrefixCode
            // 
            this.textCusPrefixCode.Location = new System.Drawing.Point(136, 73);
            this.textCusPrefixCode.Name = "textCusPrefixCode";
            this.textCusPrefixCode.Size = new System.Drawing.Size(77, 34);
            this.textCusPrefixCode.TabIndex = 34;
            this.textCusPrefixCode.TextChanged += new System.EventHandler(this.textCusPrefixCOde_TextChanged);
            // 
            // textCusID
            // 
            this.textCusID.Location = new System.Drawing.Point(266, 6);
            this.textCusID.Name = "textCusID";
            this.textCusID.Size = new System.Drawing.Size(100, 34);
            this.textCusID.TabIndex = 45;
            this.textCusID.TextChanged += new System.EventHandler(this.textCusID_TextChanged);
            // 
            // comboCusGroup
            // 
            this.comboCusGroup.FormattingEnabled = true;
            this.comboCusGroup.Items.AddRange(new object[] {
            "POS-A",
            "POS-B",
            "POS-C",
            "POS-D"});
            this.comboCusGroup.Location = new System.Drawing.Point(139, 3);
            this.comboCusGroup.Name = "comboCusGroup";
            this.comboCusGroup.Size = new System.Drawing.Size(121, 37);
            this.comboCusGroup.TabIndex = 30;
            this.comboCusGroup.SelectedIndexChanged += new System.EventHandler(this.comboCusGroup_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(38, 317);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 29);
            this.label7.TabIndex = 29;
            this.label7.Text = "วันเกิด";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(189, 268);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(190, 29);
            this.label6.TabIndex = 28;
            this.label6.Text = "เลขที่บัตรประชาชน";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioCusFemale);
            this.groupBox2.Controls.Add(this.radioCusMale);
            this.groupBox2.Location = new System.Drawing.Point(36, 249);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(146, 59);
            this.groupBox2.TabIndex = 27;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "เพศ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioCusOrg);
            this.groupBox1.Controls.Add(this.radioCusPersonal);
            this.groupBox1.Location = new System.Drawing.Point(36, 181);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(397, 64);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ประเภท";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 151);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 29);
            this.label5.TabIndex = 25;
            this.label5.Text = "นามสกุล";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 29);
            this.label4.TabIndex = 24;
            this.label4.Text = "ชื่อลูกค้า";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 29);
            this.label3.TabIndex = 23;
            this.label3.Text = "คำนำหน้า";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 29);
            this.label2.TabIndex = 22;
            this.label2.Text = "รหัส";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 29);
            this.label1.TabIndex = 21;
            this.label1.Text = "กลุ่มลูกค้า";
            // 
            // buttonInfoFromCitizenID
            // 
            this.buttonInfoFromCitizenID.Location = new System.Drawing.Point(300, 717);
            this.buttonInfoFromCitizenID.Name = "buttonInfoFromCitizenID";
            this.buttonInfoFromCitizenID.Size = new System.Drawing.Size(121, 41);
            this.buttonInfoFromCitizenID.TabIndex = 68;
            this.buttonInfoFromCitizenID.Text = "button1";
            this.buttonInfoFromCitizenID.UseVisualStyleBackColor = true;
            this.buttonInfoFromCitizenID.Click += new System.EventHandler(this.buttonInfoFromCitizenID_Click);
            // 
            // formCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 816);
            this.Controls.Add(this.buttonInfoFromCitizenID);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.checkCusSMS);
            this.Controls.Add(this.textCusDistric);
            this.Controls.Add(this.textCusDistrict);
            this.Controls.Add(this.textCusProvince);
            this.Controls.Add(this.textCusProvinceCode);
            this.Controls.Add(this.toolStripCustomer);
            this.Controls.Add(this.dtCusDOB);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.textCusSio);
            this.Controls.Add(this.textCusPostalCode);
            this.Controls.Add(this.textCusSubDistrict);
            this.Controls.Add(this.textCusNationallity);
            this.Controls.Add(this.textCusHouseNumber);
            this.Controls.Add(this.textCusEmail);
            this.Controls.Add(this.textCusMobile);
            this.Controls.Add(this.textCusTel);
            this.Controls.Add(this.textCusCitizenID);
            this.Controls.Add(this.textCusRoad);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textCusMoo);
            this.Controls.Add(this.textCusLAstName);
            this.Controls.Add(this.textCusName);
            this.Controls.Add(this.textCusPrefix);
            this.Controls.Add(this.textCusCode);
            this.Controls.Add(this.textCusPrefixCode);
            this.Controls.Add(this.textCusID);
            this.Controls.Add(this.comboCusGroup);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "formCustomer";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.formCustomer_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.toolStripCustomer.ResumeLayout(false);
            this.toolStripCustomer.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripButton toolStripSaveCus;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioCusBranch;
        private System.Windows.Forms.RadioButton radioCusHostOffice;
        private System.Windows.Forms.TextBox textCusBranchCode;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textCusBranchName;
        private System.Windows.Forms.CheckBox checkCusSMS;
        private System.Windows.Forms.TextBox textCusDistric;
        private System.Windows.Forms.TextBox textCusDistrict;
        private System.Windows.Forms.TextBox textCusProvince;
        private System.Windows.Forms.TextBox textCusProvinceCode;
        private System.Windows.Forms.ToolStrip toolStripCustomer;
        private System.Windows.Forms.ToolStripButton toolStripAddCus;
        private System.Windows.Forms.ToolStripButton toolStripEditCus;
        private System.Windows.Forms.ToolStripButton toolStripCancelCus;
        private System.Windows.Forms.DateTimePicker dtCusDOB;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textCusSio;
        private System.Windows.Forms.TextBox textCusPostalCode;
        private System.Windows.Forms.TextBox textCusSubDistrict;
        private System.Windows.Forms.TextBox textCusNationallity;
        private System.Windows.Forms.TextBox textCusHouseNumber;
        private System.Windows.Forms.TextBox textCusEmail;
        private System.Windows.Forms.TextBox textCusMobile;
        private System.Windows.Forms.TextBox textCusTel;
        private System.Windows.Forms.TextBox textCusCitizenID;
        private System.Windows.Forms.TextBox textCusRoad;
        private System.Windows.Forms.RadioButton radioCusFemale;
        private System.Windows.Forms.RadioButton radioCusOrg;
        private System.Windows.Forms.RadioButton radioCusMale;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton radioCusPersonal;
        private System.Windows.Forms.TextBox textCusMoo;
        private System.Windows.Forms.TextBox textCusLAstName;
        private System.Windows.Forms.TextBox textCusName;
        private System.Windows.Forms.TextBox textCusPrefix;
        private System.Windows.Forms.TextBox textCusCode;
        private System.Windows.Forms.TextBox textCusPrefixCode;
        private System.Windows.Forms.TextBox textCusID;
        private System.Windows.Forms.ComboBox comboCusGroup;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonInfoFromCitizenID;
    }
}

