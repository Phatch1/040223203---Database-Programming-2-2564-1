﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;


namespace Lab8_3
{
    public partial class formTitleQueries : Form
    {
        public formTitleQueries()
        {
            InitializeComponent();
        }

        private Lab8_1.MyBooksDBEntities dbcontext = new Lab8_1.MyBooksDBEntities();

        private void formTitleQueries_Load(object sender, EventArgs e)
        {
            dbcontext.Titles.Load(); //load Titles to memory

            queryComboBox.SelectedIndex = 0;

        }

        private void queryComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (queryComboBox.SelectedIndex)
            {
                case 0:
                    titleBindingSource.DataSource = dbcontext.Titles.Local.OrderBy(book => book.Title1);
                    break;
                case 1:
                    titleBindingSource.DataSource = dbcontext.Titles.Local
                        .Where(book => book.Copyright == "2016")
                        .OrderBy(book => book.Title1);
                    break;
                case 2:
                    titleBindingSource.DataSource = dbcontext.Titles.Local
                        .Where(book => book.Title1.EndsWith("How to Program"))
                        .OrderBy(book => book.Title1);
                    break;
            }
            titleBindingSource.MoveFirst();//move to first entry
        }
    }
}
