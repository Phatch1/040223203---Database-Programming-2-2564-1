﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;
using System.Data.Entity.Validation;

namespace Lab8_2
{
    public partial class formDisplayAuthorsTable : Form
    {
        public formDisplayAuthorsTable()
        {
            InitializeComponent();
        }
        private Lab8_1.MyBooksDBEntities dbcontext=new Lab8_1.MyBooksDBEntities();
        
        private void formDisplayAuthorsTable_Load(object sender, EventArgs e)
        {
            //load Author table order by Lastname then Firstname
            dbcontext.Authors
                .OrderBy(author => author.LastName)
                .ThenBy(author => author.FirstName)
                .Load();
            //Specify datasource for authorBindingSource
            authorBindingSource.DataSource = dbcontext.Authors.Local;
        }

        private void authorBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            Validate();//Validate input field
            authorBindingSource.EndEdit();
            try
            {
                dbcontext.SaveChanges();
            }
            catch (DbEntityValidationException)
            {
                MessageBox.Show("");
            }
        }
    }
}
