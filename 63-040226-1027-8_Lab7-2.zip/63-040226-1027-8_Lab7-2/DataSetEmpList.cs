﻿namespace Lab7_2
{


    partial class DataSetEmpList
    {
    }
}

namespace Lab7_2.DataSetEmpListTableAdapters {
    
    
    public partial class EmployeesTableAdapter {
    }
}
