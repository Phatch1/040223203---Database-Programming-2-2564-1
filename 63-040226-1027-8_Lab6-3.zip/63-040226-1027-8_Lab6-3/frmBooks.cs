﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Lab6_3
{
    public partial class frmBooks : Form
    {

        SqlConnection booksConnection;
        String SQLAll;
        Button[] buttonRolodex = new Button[26];
        public frmBooks()
        {
            InitializeComponent();
        }

        private void frmBooks_Load(object sender, EventArgs e)
        {
            booksConnection = new SqlConnection("Data Source=LEGIONY450;"+
                "Initial Catalog=DemoBooksDB;" +
                "User ID=user1;Password=mypass1");
            booksConnection.Open();

            // Create Rolodex buttons for searching
            int w, lStart, l, t;
            int buttonHeight = 33;

            // Found by trial and error
            // search buttons
            // determine button width - 13 on a row

            w = Convert.ToInt32(this.ClientSize.Width / 14);

            // Center buttons on form
            lStart = Convert.ToInt32(0.5 * (this.ClientSize.Width - 13 * w));
            l = lStart;
            t = dataGridBooks.Top + dataGridBooks.Height + 2;

            // Create and position 26 buttons
            for (int i = 0; i < 26; i++)
            {

                // Create new pushbutton
                buttonRolodex[i] = new Button();
                buttonRolodex[i].TabStop = false;
                // Set text property
                buttonRolodex[i].Text = ((char)(65 + i)).ToString();
                // Position
                buttonRolodex[i].Width = w;
                buttonRolodex[i].Height = buttonHeight;
                buttonRolodex[i].Left = l;
                buttonRolodex[i].Top = t;
                // Give cool colors
                buttonRolodex[i].BackColor = Color.Blue;
                buttonRolodex[i].ForeColor = Color.White;
                // Add button to form
                this.Controls.Add(buttonRolodex[i]);
                // Add event handler
                buttonRolodex[i].Click += new
                    System.EventHandler(this.buttonSQL_Click);
                // Next left
                l += w;
                if (i == 12)
                {
                    // Move to next row
                    l = lStart;
                    t += buttonHeight;
                }
            }
            // Build basic SQL statement
            SQLAll = "SELECT Authors.Author,Titles.Title,Publishers.Company_Name ";
            SQLAll += "FROM Authors, Titles, Publishers, Title_Author ";
            SQLAll += "WHERE Titles.ISBN = Title_Author.ISBN ";
            SQLAll += "AND Authors.Au_ID = Title_Author.Au_ID ";
            SQLAll += "AND Titles.PubID = Publishers.PubID ";
            // Show form and click on all records initially
            this.Show();
            buttonAll.PerformClick();
        }

        private void frmBooks_FormClosing(object sender, FormClosingEventArgs e)
        {
            booksConnection.Close();
            booksConnection.Dispose();
        }

        private void buttonSQL_Click(object sender, EventArgs e)
        { 

        SqlCommand resultsCommand = null;
        SqlDataAdapter resultsAdapter = new SqlDataAdapter();

        DataTable resultsTable = new DataTable();

        String SQLStatement;

        // determine which button was clicked and form SQL statement

        Button buttonClicked = (Button)sender;

        switch (buttonClicked.Text) {

	    case "แสดงระเบียนทั้งหมด":
		SQLStatement = SQLAll;
		break;
	    case "Z":
		// Z Clicked
		// Append to SQLAll to limit records to Z Authors
		SQLStatement = SQLAll + "AND Authors.Author > 'Z' ";
		break;
	    default:
		// Letter key other than Z clicked
		// Append to SQLAll to limit records to letter clicked
		int index = (int)(Convert.ToChar(buttonClicked.Text)) - 65;
        SQLStatement = SQLAll + "AND Authors.Author > '" + buttonRolodex[index].Text + " ' ";
		SQLStatement += "AND Authors.Author < '" + buttonRolodex[index + 1].Text + " ' ";
		break;

}
     SQLStatement += "ORDER BY Authors.Author";
// Apply SQL statement
     try {
	// Establish command object and data adapter
	resultsCommand = new SqlCommand(SQLStatement, booksConnection);
    resultsAdapter.SelectCommand = resultsCommand;
	resultsAdapter.Fill(resultsTable);
	// Bind grid view to data table
	dataGridBooks.DataSource = resultsTable;
}
catch (Exception ex)
{
    MessageBox.Show(ex.Message, "Error in Processing SQL",
    MessageBoxButtons.OK, MessageBoxIcon.Error);
}
resultsCommand.Dispose();
resultsAdapter.Dispose();
resultsTable.Dispose();
        }
    }
    }

