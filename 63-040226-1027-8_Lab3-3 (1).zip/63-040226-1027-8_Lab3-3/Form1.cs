﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Lab3_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection cnn;
        private void buttonConnect_Click(object sender, EventArgs e)
        {
            try
            {
                string strConnectionString;
                SqlConnection cnn;
                strConnectionString = @"Data Source=LEGIONY450;
                Initial Catalog = DemoTutorialDB;User ID=user1;Password=mypass1";
                cnn = new SqlConnection(strConnectionString);
                cnn.Open();
                MessageBox.Show("การเชอมต่อสําเร็จ", "เชื่อมต่อ",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information,
                MessageBoxDefaultButton.Button1);

                cnn.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("มปีัญหาการเชื่อมต่อ!" + ex.Message, "ข้อผิดพลาด",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error,
                MessageBoxDefaultButton.Button1);
            }
        }

        private void buttonQuery_Click(object sender, EventArgs e)
        {
            SqlCommand command;
            SqlDataReader dataReader;
            String strSQL, strOutput = "";
            cnn = new SqlConnection(@"Data Source=LEGIONY450;Initial Catalog=DemoTutorialDB;User ID=user1; Password=mypass1;");
            strSQL = "Select TutorialID,TutorialName from TutorialCourse";

            command = new SqlCommand(strSQL, cnn);
            cnn.Open();
            dataReader = command.ExecuteReader();
            while (dataReader.Read())
            {
                strOutput = strOutput + dataReader.GetValue(0) + " ‐ " + dataReader.GetValue(1) + "\n";

            }
            MessageBox.Show(strOutput);
            dataReader.Close();
            command.Dispose();
            cnn.Close();
        }

        private void buttonInsert_Click(object sender, EventArgs e)
        {
            SqlCommand command;
            SqlDataAdapter adapter = new SqlDataAdapter();
            String strSQL;
            cnn = new SqlConnection(@"Data Source=LEGIONY450;Initial Catalog=DemoTutorialDB;User ID=user1; Password=mypass1;");
            strSQL = "Select TutorialID,TutorialName from TutorialCourse";
            cnn.Open();
            strSQL = @"Insert into TutorialCourse (TutorialID,TutorialName)
            values(3, '" + "VB.NET" + "')";
            command = new SqlCommand(strSQL, cnn);
            adapter.InsertCommand = command;
            adapter.InsertCommand.ExecuteNonQuery();
            command.Dispose();
            cnn.Close();
        }
    }
}
