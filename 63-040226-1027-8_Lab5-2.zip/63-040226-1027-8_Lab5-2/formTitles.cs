﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Lab5_2
{
    public partial class formTitles : Form
    {
        SqlConnection booksConnection;
        public formTitles()
        {
            InitializeComponent();
        }

        private void formTitles_Load(object sender, EventArgs e)
        {
            booksConnection = new SqlConnection(
                            "Data Source=LEGIONY450;" + "Initial Catalog=DemoBooksDB;" + "User ID=user1;" + "Password=mypass1;");
            booksConnection.Open();
            lblState.Text += booksConnection.State.ToString() + "\n";
            var titlesCommand = new SqlCommand("Select * from Titles", booksConnection);
            booksConnection.Close();
            lblState.Text += booksConnection.State.ToString() + "\n";
            booksConnection.Dispose();
            titlesCommand.Dispose();
        }
    }
}
