﻿namespace _63_040226_1027_8_Lab6
{
    partial class formSQLTester
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridSQLTester = new System.Windows.Forms.DataGridView();
            this.textSQLTester = new System.Windows.Forms.TextBox();
            this.buttonTest = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labelRecords = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSQLTester)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridSQLTester
            // 
            this.dataGridSQLTester.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridSQLTester.Location = new System.Drawing.Point(62, 54);
            this.dataGridSQLTester.Name = "dataGridSQLTester";
            this.dataGridSQLTester.RowHeadersWidth = 51;
            this.dataGridSQLTester.RowTemplate.Height = 24;
            this.dataGridSQLTester.Size = new System.Drawing.Size(689, 262);
            this.dataGridSQLTester.TabIndex = 0;
            this.dataGridSQLTester.TabStop = false;
            // 
            // textSQLTester
            // 
            this.textSQLTester.Location = new System.Drawing.Point(49, 337);
            this.textSQLTester.Multiline = true;
            this.textSQLTester.Name = "textSQLTester";
            this.textSQLTester.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textSQLTester.Size = new System.Drawing.Size(335, 133);
            this.textSQLTester.TabIndex = 1;
            // 
            // buttonTest
            // 
            this.buttonTest.Location = new System.Drawing.Point(446, 338);
            this.buttonTest.Name = "buttonTest";
            this.buttonTest.Size = new System.Drawing.Size(270, 33);
            this.buttonTest.TabIndex = 2;
            this.buttonTest.TabStop = false;
            this.buttonTest.Text = "ทดสอบคำสั่ง SQL";
            this.buttonTest.UseVisualStyleBackColor = true;
            this.buttonTest.Click += new System.EventHandler(this.buttonTest_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(390, 400);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(172, 60);
            this.label1.TabIndex = 3;
            this.label1.Text = "จำนวนระเบียนทีคืนต่า :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelRecords
            // 
            this.labelRecords.BackColor = System.Drawing.Color.White;
            this.labelRecords.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelRecords.Location = new System.Drawing.Point(581, 390);
            this.labelRecords.Name = "labelRecords";
            this.labelRecords.Size = new System.Drawing.Size(217, 80);
            this.labelRecords.TabIndex = 4;
            this.labelRecords.Text = "0";
            this.labelRecords.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // formSQLTester
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(840, 509);
            this.Controls.Add(this.labelRecords);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonTest);
            this.Controls.Add(this.textSQLTester);
            this.Controls.Add(this.dataGridSQLTester);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "formSQLTester";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ตัวทกสอบ SQL";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.formSQLTester_FormClosing);
            this.Load += new System.EventHandler(this.formSQLTester_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSQLTester)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridSQLTester;
        private System.Windows.Forms.TextBox textSQLTester;
        private System.Windows.Forms.Button buttonTest;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelRecords;
    }
}

