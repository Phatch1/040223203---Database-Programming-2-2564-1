﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _63_040226_1027_8_Lab6
{
    public partial class formSQLTester : Form
    {
        SqlConnection booksConnection;
        public formSQLTester()
        {
            InitializeComponent();
        }

        
        private void formSQLTester_Load(object sender, EventArgs e)
        {
            booksConnection = new SqlConnection("Data Source=LEGIONY450;" 
                + "Initial Catalog=DemoBooksDB;" 
                + "User ID=user1;" + "Password=mypass1");
            booksConnection.Open();
        }

        private void formSQLTester_FormClosing(object sender, FormClosingEventArgs e)
        {
            booksConnection.Close();
            booksConnection.Dispose();
        }

        private void buttonTest_Click(object sender, EventArgs e)
        {
            SqlCommand resultCommand = null;
            SqlDataAdapter resultAdapter = new SqlDataAdapter();
            DataTable resultTable = new DataTable();
            try
            {
                // Establish command object and data adapter
                resultCommand = new SqlCommand(textSQLTester.Text, booksConnection);
                resultAdapter.SelectCommand = resultCommand;
                resultAdapter.Fill(resultTable);

                dataGridSQLTester.DataSource = resultTable;
                labelRecords.Text = resultTable.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "เกิดข้อผิดพลาดในการประมวลผลคำสั่ง SQL", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            resultAdapter.Dispose();
            resultCommand.Dispose();
            resultTable.Dispose();
        }
    }
}
