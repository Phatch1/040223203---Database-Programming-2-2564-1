﻿namespace Lab5_4
{
    partial class formTitles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textTitle = new System.Windows.Forms.TextBox();
            this.textYearPublished = new System.Windows.Forms.TextBox();
            this.textISBN = new System.Windows.Forms.TextBox();
            this.textPubID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(104, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(172, 29);
            this.label2.TabIndex = 0;
            this.label2.Text = "YearPublished";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(151, 211);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 29);
            this.label3.TabIndex = 0;
            this.label3.Text = "ISBN";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(151, 280);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 29);
            this.label4.TabIndex = 0;
            this.label4.Text = "PubID";
            // 
            // textTitle
            // 
            this.textTitle.BackColor = System.Drawing.Color.White;
            this.textTitle.Location = new System.Drawing.Point(282, 83);
            this.textTitle.Multiline = true;
            this.textTitle.Name = "textTitle";
            this.textTitle.ReadOnly = true;
            this.textTitle.Size = new System.Drawing.Size(287, 46);
            this.textTitle.TabIndex = 1;
            // 
            // textYearPublished
            // 
            this.textYearPublished.BackColor = System.Drawing.Color.White;
            this.textYearPublished.Location = new System.Drawing.Point(282, 146);
            this.textYearPublished.Multiline = true;
            this.textYearPublished.Name = "textYearPublished";
            this.textYearPublished.ReadOnly = true;
            this.textYearPublished.Size = new System.Drawing.Size(287, 46);
            this.textYearPublished.TabIndex = 1;
            // 
            // textISBN
            // 
            this.textISBN.BackColor = System.Drawing.Color.White;
            this.textISBN.Location = new System.Drawing.Point(282, 211);
            this.textISBN.Multiline = true;
            this.textISBN.Name = "textISBN";
            this.textISBN.ReadOnly = true;
            this.textISBN.Size = new System.Drawing.Size(287, 46);
            this.textISBN.TabIndex = 1;
            // 
            // textPubID
            // 
            this.textPubID.BackColor = System.Drawing.Color.White;
            this.textPubID.Location = new System.Drawing.Point(282, 280);
            this.textPubID.Multiline = true;
            this.textPubID.Name = "textPubID";
            this.textPubID.ReadOnly = true;
            this.textPubID.Size = new System.Drawing.Size(287, 46);
            this.textPubID.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(169, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Title";
            // 
            // formTitles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(828, 449);
            this.Controls.Add(this.textPubID);
            this.Controls.Add(this.textISBN);
            this.Controls.Add(this.textYearPublished);
            this.Controls.Add(this.textTitle);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "formTitles";
            this.Text = "ฐานข้อมูลชื่อหนังสือ";
            this.Load += new System.EventHandler(this.formTitles_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textTitle;
        private System.Windows.Forms.TextBox textYearPublished;
        private System.Windows.Forms.TextBox textISBN;
        private System.Windows.Forms.TextBox textPubID;
        private System.Windows.Forms.Label label1;
    }
}

